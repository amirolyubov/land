import Gallery__desktop from './Gallery__desktop.jsx'
import Gallery__mobile from './Gallery__mobile.jsx'

export { Gallery__desktop, Gallery__mobile }
