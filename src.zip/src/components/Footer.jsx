import React, { Component } from 'react'

class Footer extends Component {
  constructor (props) {
    super(props)
  }
  render () {
    return (
      <footer>
        <div>
          <p>«БАШНЯ ФЕДЕРАЦИЯ» Пресненская наб. 12, 19.2, Москва</p>
          <p>2018 YIG - Yachts & Immovables Group</p>
        </div>
        <p>+7 (495) 777-77-77</p>
      </footer>
    )
  }
}

export default Footer
